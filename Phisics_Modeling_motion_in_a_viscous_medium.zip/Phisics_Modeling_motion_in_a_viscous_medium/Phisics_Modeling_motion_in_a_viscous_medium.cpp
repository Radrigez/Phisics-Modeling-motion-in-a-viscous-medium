﻿#include <iostream>
#include <cmath>
#include <fstream>
#include <iomanip>

using namespace std;

int main() {

    ofstream F;

    F.open("D:\\Mod.txt", ios::out);
    
   

    double m, g, Rs, Rm, Mm, Mg, Vy0, t, pi, R, k1, Fc, Fa, MA, V, V0, Y, X, k2, B, Vy, i;
    m = 0.00054;               
    g = 9.81;                   
    Rs = 1130;                  
    Mm = 950;                  
    Mg = 1480;                  
    Vy0 = 0.01;                 
    double t0 = 0;              
    pi = 3.14;                              
    R = sqrt(m / (Rs * 4 * pi));          
    k1 = 6 * pi * Mm * R;                 
    k2 = 6 * pi * Mg * R;                 
    double h0 = 10;                    
    double h = 0;                      
                   
    t = 0;                     



   
    V = Vy0 + t / 2 * (((m * g - k1 * Vy0 * Vy0) / (m + (m * g - k1 * ((Vy0 + t * (m * g - k1 * Vy0 * Vy0) / m) * (Vy0 + t * (m * g - k1 * Vy0 * Vy0)) / m))))) / m;

 
    while (true)
    {
        t = t++;

        V = Vy0 + t / 2 * (((m * g - k1 * Vy0 * Vy0) / (m + (m * g - k1 * ((Vy0 + t * (m * g - k1 * Vy0 * Vy0) / m) * (Vy0 + t * (m * g - k1 * Vy0 * Vy0)) / m))))) / m;

        double h = h0 - V * t;

        F << "  " << h << "    " << t << "  " << V << endl;

        if (t > 20)

            break;

        if (h < 0)

            break;

    }

    F << "end!" << endl;

 
    double t2 = 0;
    double V2, h2;
    while (true)
    {
        t2 = t2++;

        V2 = Vy0 + t2 / 2 * (((m * g - k2 * Vy0 * Vy0) / (m + (m * g - k2 * ((Vy0 + t2 * (m * g - k2 * Vy0 * Vy0) / m) * (Vy0 + t * (m * g - k2 * Vy0 * Vy0)) / m))))) / m;

        double h2 = h0 - V2 * t2;

        F << " | h =   " << h2 << " |" << "  | t =   " << t2 << " |" << " | V =  " << V2 << " |" << endl;
       // F << h << endl;
       // F << t << endl;
       //F << V << endl;


        if (t2 > 40)

            break;

        if (h2 < 0)

            break;

    }

    F.close();


    return 0;
}